# Minhas Finanças: versão para Android

A pasta `www` é o app completo (funciona offline depois do primeiro acesso online, que baixa o gerador de PDF).

## Opção A: instalar como app pelo Chrome (mais rápida)
1. Hospede o conteúdo da pasta `www` em qualquer site HTTPS (por exemplo GitHub Pages ou Netlify).
2. Abra o endereço no Chrome do celular Android.
3. Menu ⋮ > **Instalar app** (ou "Adicionar à tela inicial"). Ele abre em tela cheia, com ícone próprio.

## Opção B: gerar o arquivo APK
Precisa de um computador com **Node.js** e **Android Studio** instalados.
1. Nesta pasta: `npm install`
2. `npx cap add android`
3. `npx cap sync`
4. `npx cap open android` (abre o Android Studio)
5. No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. Envie o `app-debug.apk` gerado para o celular e instale (é preciso permitir "instalar apps desconhecidos").

## Diferenças em relação à versão do Claude
- A leitura de nota fiscal por foto (IA) não existe aqui. Os gastos são lançados à mão.
- PDF e backup abrem a tela de compartilhar do Android, onde você salva no Drive, arquivos ou envia por WhatsApp. No APK isso pode variar conforme a versão do sistema.
- Os dados ficam só no aparelho. Use o backup (JSON) para não perdê-los.
- Ao atualizar os arquivos, mude `fin-v1` em `sw.js` para outro nome para o celular baixar a versão nova.
